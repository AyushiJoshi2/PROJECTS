function Demo()
{
    x = document.getElementById('j1').value;
    if(x.length>=3){
        form1.submit();
    }
    else{
        document.getElementById('s1').innerHTML="Invalid User Name";
    }
y = document.getElementById('j').value;
    if(y.length>=3){
        form1.submit();
    }
    else{
        document.getElementById('s').innerHTML="Invalid password type";
    }
}